package com.ct.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.ct.model.Tv;

@Component
public interface ITvConnect {

	public void addTv(Tv t);
	public List<Tv> displayTv();
	public Tv retriveTv(int tId);
}
