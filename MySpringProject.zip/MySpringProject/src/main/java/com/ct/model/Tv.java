package com.ct.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity

public class Tv implements Serializable {
	
	@Id
	private int tvId;
	@Size(min=3, max=17,message="TV name cannot be less than 3 or greater than 17 characters")
	@NotNull(message="field is mandatory") 
	private String tvName;
	@NotNull(message="field is mandatory")
	private String tvBrand;
	@NotNull(message="field is mandatory")
	private int tvPrice;
	@NotNull(message="field is mandatory")
	private int tvQuantity;
	@Size(min=3, max=17,message="TV Description cannot be less than 3 or greater than 17 characters")
	@NotNull(message="field is mandatory")
	private String tvDescription;
	@NotNull(message="field is mandatory")
	private int tvDiscount;
	
	
	
	public int getTvId() {
		return tvId;
	}
	public void setTvId(int tvId) {
		this.tvId = tvId;
	}
	public String getTvName() {
		return tvName;
	}
	public void setTvName(String tvName) {
		this.tvName = tvName;
	}
	public String getTvBrand() {
		return tvBrand;
	}
	public void setTvBrand(String tvBrand) {
		this.tvBrand = tvBrand;
	}
	public int getTvPrice() {
		return tvPrice;
	}
	public void setTvPrice(int tvPrice) {
		this.tvPrice = tvPrice;
	}
	public int getTvQuantity() {
		return tvQuantity;
	}
	public void setTvQuantity(int tvQuantity) {
		this.tvQuantity = tvQuantity;
	}
	public String getTvDescription() {
		return tvDescription;
	}
	public void setTvDescription(String tvDescription) {
		this.tvDescription = tvDescription;
	}
	public int getTvDiscount() {
		return tvDiscount;
	}
	public void setTvDiscount(int tvDiscount) {
		this.tvDiscount = tvDiscount;
	}
	public Tv(int tvId, String tvName, String tvBrand, int tvPrice, int tvQuantity, String tvDescription, int tvDiscount) {
		this.tvId = tvId;
		this.tvName = tvName;
		this.tvBrand = tvBrand;
		this.tvPrice = tvPrice;
		this.tvQuantity = tvQuantity;
		this.tvDescription = tvDescription;
		this.tvDiscount = tvDiscount;
	}
	public Tv() {
		
	}
	@Override
	public String toString() {
		return "Tv [tvId=" + tvId + ", tvName=" + tvName + ", tvBrand=" + tvBrand + ", tvPrice=" + tvPrice
				+ ", tvQuantity=" + tvQuantity + ", tvDescription=" + tvDescription + ", tvDiscount=" + tvDiscount
				+ "]";
	}
}
	
	
	
	
	