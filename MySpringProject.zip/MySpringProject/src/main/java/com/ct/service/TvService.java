package com.ct.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.ct.dao.ITvConnect;
import com.ct.model.Tv;

@Service
public class TvService implements ITvService {

	ModelAndView mService = new ModelAndView();
	@Autowired
	ITvConnect tConnect;
	
	
	public ModelAndView predAdd() {
		mService.addObject("tv", new Tv());
		return mService; 
	}

	public void addTv(Tv t) {
		
		tConnect.addTv(t);
		
	}

	@Override
	public  List<Tv> displayTv() {
	 List<Tv> tv = tConnect.displayTv();
	 return tv;
		
	}

	@Override
	public Tv retriveTv(int tId) {
		Tv t = tConnect.retriveTv(tId);
		return t;
	}



}
